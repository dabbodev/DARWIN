# DARWIN Simulator

**DARWIN** stands for **Direct-Access Registration Window Interface Network**.

DARWIN is an experimental identity-aware network model where devices carry durable identities, register through scoped namespaces, route through Traffic Hubs, and can move between network branches without losing their logical identity.

This repository is intended to become a **simulator-first prototype**, not a real network stack. The first goal is to model DARWIN behavior clearly enough to test registration, movement, routing, checkpointing, lane pause/resume, conflicts, and symbolic trust decisions before attempting real sockets, production cryptography, kernel networking, DNS integration, or hardware identity.

## Current Status

This project is currently in the **concept and simulator planning phase**.

The v0.1 simulator should answer questions like:

- Can a device register under a scoped Registry Hub?
- Can two devices reuse the same local label in different scopes?
- Can a hub detect a same-scope label conflict and assign a temporary label?
- Can a device move from one hub to another while preserving identity?
- Can active logical lanes pause while a device is `in_transit`?
- Can lanes resume after a verified symbolic move?
- Can symbolic authentication failures quarantine a spoofed actor?
- Can repeated traffic pressure produce a bridge recommendation?

The simulator should make those behaviors visible through logs, snapshots, scenario files, and tests.

## Core Concepts

### Device Identity

A DARWIN device has a durable `device_id`.

The `device_id` should not depend on the current IP address, MAC address, local attachment point, or display label. In later phases, this identity may be tied to a cryptographic keypair. In v0.1, identity can be represented symbolically.

```text
Device Identity = who the device is
Attachment      = where the device is currently connected
Label           = local human-readable name
```

### Scoped Labels and Registry Paths

Device labels are scoped. A label only needs to be unique inside its local Registry Hub scope.

```text
global.family.david.home.printer
global.family.david.office.printer
global.company.lab.printer
```

Those can all be valid because each `printer` label belongs to a different scope.

### Registry Hubs

A **Registry Hub** manages identity, labels, passports, summaries, attachment state, checkpoint state, move history, conflicts, revocation, and authority inside a scope.

Registry Hubs answer questions like:

```text
Who is this device?
What label does it have here?
Is its passport valid?
Where is it currently attached?
Has it moved recently?
Should I ask a parent or witness hub?
```

### Traffic Hubs

A **Traffic Hub** moves packets and manages routes, lanes, forwarding, congestion, route probes, relocation handoffs, flow control, and traffic bridge recommendations.

Traffic Hubs answer questions like:

```text
How do packets reach this device right now?
Is this lane active, paused, rerouting, or blocked?
Should traffic be forwarded, held, dropped, or redirected?
Is congestion building?
Should a traffic bridge be recommended?
```

### Hybrid Hubs

A **Hybrid Hub** performs both Registry Hub and Traffic Hub roles.

For v0.1, prefer composition over complicated inheritance:

```text
HybridHub
  registry: RegistryHub
  traffic: TrafficHub
```

### Passports

A DARWIN passport is the root identity record for a device.

It represents the first approved registration of a device into a scope. In production, it would likely involve public-key signatures and issuer trust. In v0.1, it should be symbolic.

```yaml
PassportRecord:
  passport_id: cert_123
  device_id: dev_A9F3
  issued_by: hub_home_001
  issued_scope: global.family.david.home
  valid: true
  revoked: false
```

### Move Contracts

A **Move Contract** records that a device moved between scopes or attachment points. It references the passport and prevents a new hub from simply claiming a device without proof.

For v0.1, move validity can be represented with a simple symbolic flag.

```yaml
MoveContract:
  move_id: move_001
  passport_id: cert_123
  device_id: dev_A9F3
  from_scope: global.family.david.home
  to_scope: global.family.david.office
  old_attachment: hub_home_001
  new_attachment: hub_office_007
  valid: true
```

### Local Rolling Proof

Passports are for heavier cross-network or cross-scope identity checks.

Local rolling proof is for same-network continuity. It helps prevent a device from gaining access by spoofing a MAC address, local address, label, or stale attachment hint.

In v0.1, this is symbolic:

```yaml
auth_state:
  passport_valid: true
  issuer_trusted: true
  rolling_proof_valid: true
  packet_auth_tag_valid: true
```

Future phases may replace these fields with real challenge-response, HMAC, CMAC, signatures, counters, epochs, and replay protection.

### Checkpoints

Checkpoint packets report liveness and state.

Common device states include:

```text
unknown
claiming_identity
passport_verified
locally_authenticated
online
idle
active
disconnected
in_transit
awaiting_verification
timed_out
offline
quarantined
revoked
rejected
```

Checkpoint tiers allow different devices to report at different rates:

```text
Tier 0 = sparse / passive IoT
Tier 1 = normal smart device
Tier 2 = mobile interactive device
Tier 3 = critical / real-time device
```

### Logical Lanes

A **Logical Lane** is a persistent connection relationship between authenticated device identities.

A lane is not just a route. It tracks source identity, target identity, lane mode, sequence state, acknowledgments, route state, flow state, and relocation state.

Example states:

```text
opening
active
flow_hold
paused_relocation
awaiting_verification
rerouting
resumed
closing
terminated
conflict_detected
quarantined
```

During relocation, DARWIN should pause senders and avoid unbounded buffering.

```text
active -> paused_relocation -> awaiting_verification -> rerouting -> resumed -> active
```

## Planned Simulator

The first simulator should be a deterministic, in-memory Python model.

It should use:

- Python 3.11+
- `dataclasses` or Pydantic for models
- `pytest` for tests
- YAML or JSON scenario files
- optional `rich` output for readable logs
- optional `networkx` for graph routing experiments later

The simulator should model DARWIN as objects interacting through explicit events.

Example event types:

```text
DeviceConnects
DeviceRegisters
DeviceSendsCheckpoint
DeviceOpensLane
PacketSent
PacketForwarded
PacketAcknowledged
DeviceDisconnects
DeviceMarkedInTransit
SenderFlowHeld
DeviceReconnects
MoveVerified
RouteUpdated
LaneResumed
ConflictDetected
DeviceQuarantined
GrowthRecommended
```

The simulator should use simulated time rather than wall-clock time so tests remain deterministic.

## Suggested Repository Structure

```text
darwin_sim/
  README.md
  pyproject.toml
  docs/
    DARWIN_Design_Dossier_v0_1.md
    DARWIN_Identity_Trust_Authentication_v0_1.md
    DARWIN_Packet_Checkpoint_Lane_Protocol_v0_1.md
    DARWIN_Registry_Hub_Data_Model_v0_1.md
    DARWIN_Traffic_Hub_Routing_Model_v0_1.md
    DARWIN_Simulator_Build_Plan_v0_1.md
  darwin/
    __init__.py
    ids.py
    models/
      __init__.py
      device.py
      hub.py
      passport.py
      packet.py
      lane.py
      route.py
      checkpoint.py
      events.py
      policies.py
    sim/
      __init__.py
      world.py
      runner.py
      scenarios.py
      event_log.py
      assertions.py
    registry/
      __init__.py
      operations.py
      summaries.py
      conflicts.py
    traffic/
      __init__.py
      routing.py
      lanes.py
      relocation.py
      metrics.py
    auth/
      __init__.py
      symbolic.py
      trust.py
    cli/
      __init__.py
      main.py
  scenarios/
    001_basic_registration.yaml
    002_name_conflict.yaml
    003_lane_open_and_send.yaml
    004_relocation_pause_resume.yaml
    005_relocation_timeout.yaml
    006_mac_spoof_symbolic_failure.yaml
    007_congestion_bridge_recommendation.yaml
  tests/
    test_registration.py
    test_conflicts.py
    test_lanes.py
    test_relocation.py
    test_routing.py
    test_auth_symbolic.py
```

## Quick Start Placeholder

This is the intended future shape once the package skeleton exists.

```bash
git clone <repo-url>
cd darwin_sim
python -m venv .venv
```

Activate the environment:

```bash
# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS / Linux
source .venv/bin/activate
```

Install in editable mode:

```bash
pip install -e ".[dev]"
```

Run tests:

```bash
pytest
```

Run a scenario:

```bash
darwin-sim run scenarios/001_basic_registration.yaml
```

Run a relocation scenario with a final snapshot:

```bash
darwin-sim run scenarios/004_relocation_pause_resume.yaml --dump-snapshot
```

List scenarios:

```bash
darwin-sim list-scenarios
```

## First Development Milestones

### Milestone 1: Basic Object World

Goal: create the smallest working simulation world.

Deliverables:

```text
World exists
Devices can be created
Hubs can be created
Hubs can connect
Devices can attach to hubs
One trivial scenario runs
```

Success check:

```text
A device object and hub object can be created, attached, logged, and printed.
```

### Milestone 2: Registry Works

Goal: implement scoped registration.

Deliverables:

```text
RegistryHub
Device
PassportRecord
LocalDeviceRecord
Label Index
Device ID Index
Attachment Index
register_device()
resolve_label()
resolve_device_id()
assign_temp_label()
```

Success check:

```text
dev_A9F3 registers as global.family.david.home.my_pc.
dev_B2C8 requests my_pc in the same scope and receives my_pc_temp_B2C8.
```

### Milestone 3: Traffic Works

Goal: move symbolic packets through a route graph.

Deliverables:

```text
TrafficHub
Neighbor Table
Direct Attachment Table
Route Table
select_route()
forward_packet()
basic route cost
packet forwarding logs
```

Success check:

```text
A packet moves from Device A through Hub 1, Hub 2, and Hub 3 to Device B.
```

### Milestone 4: Logical Lanes Work

Goal: model persistent identity-bound connections.

Deliverables:

```text
LogicalLane
lane_open
lane_open_ack
lane states
sequence numbers
acknowledgments
basic data packet forwarding
```

Success check:

```text
Device A opens lane_001 to Device B, sends packet 1, and receives ack 1.
```

### Milestone 5: Checkpoints Work

Goal: track liveness and state.

Deliverables:

```text
CheckpointPacket
checkpoint tiers
record_checkpoint()
missed checkpoint detection
online, idle, active, timed_out, offline states
```

Success check:

```text
A Tier 2 mobile device updates frequently.
A Tier 0 sensor remains valid with sparse checkpoints.
```

### Milestone 6: Relocation Works

Goal: pause and resume lanes during movement.

Deliverables:

```text
mark_in_transit()
flow_hold
pause_lane_for_relocation()
MoveContract symbolic record
update_attachment()
relocation_resume
resume_lane_after_relocation()
resume sequence behavior
```

Success check:

```text
Device B moves from Hub 3 to Hub 4.
Sender pauses while B is in_transit.
Lane resumes from the correct sequence after B registers at Hub 4.
```

### Milestone 7: Symbolic Security Failures Work

Goal: model trust failure outcomes before real cryptography.

Deliverables:

```text
passport_valid flag
issuer_trusted flag
rolling_proof_valid flag
auth_tag_valid flag
quarantine state
security event log
MAC spoof symbolic scenario
```

Success check:

```text
A spoofed actor claiming dev_A9F3 fails rolling proof and is quarantined.
```

### Milestone 8: Metrics and Growth Recommendations Work

Goal: detect routing pressure and recommend growth.

Deliverables:

```text
lookup counts
route counts
cross-tree traffic count
lane pause count
relocation count
congestion score
traffic bridge recommendation
registry split recommendation
```

Success check:

```text
Repeated traffic between home and office branches produces a create_traffic_bridge recommendation.
```

## Documentation

The following design documents should live in `docs/` and remain the source of truth until superseded:

1. `DARWIN_Design_Dossier_v0_1.md`
2. `DARWIN_Identity_Trust_Authentication_v0_1.md`
3. `DARWIN_Packet_Checkpoint_Lane_Protocol_v0_1.md`
4. `DARWIN_Registry_Hub_Data_Model_v0_1.md`
5. `DARWIN_Traffic_Hub_Routing_Model_v0_1.md`
6. `DARWIN_Simulator_Build_Plan_v0_1.md`

## What v0.1 Is Not

DARWIN simulator v0.1 is not:

- a replacement for TCP/IP
- a VPN
- a real router
- a real authentication system
- a production security library
- a DNS replacement
- a kernel module
- a packet capture tool
- a cryptography experiment
- a deployable network product

The v0.1 simulator is a behavioral model. It should prove whether the state machines, tables, events, and flows make sense.

## Future Phases

### Future Phase: Real Cryptography

Replace symbolic fields with standard, reviewed mechanisms:

```text
public-key signatures for passports and move contracts
HMAC or CMAC-style local session proofs
counter, nonce, timestamp, and epoch replay protection
auth tags for packet and checkpoint validation
revocation checks
key rotation behavior
```

Avoid custom cryptography. The simulator can model crypto concepts first, but production phases should use well-reviewed standard constructions.

### Future Phase: Localhost Prototype

Run hubs as local processes communicating over HTTP, WebSocket, or TCP.

Demonstrate:

```text
device registration
name conflict handling
move contract creation
in_transit pause/resume
checkpoint updates
route updates
```

### Future Phase: LAN Overlay Prototype

Use existing IP networking for physical delivery while DARWIN handles identity, registry behavior, movement, checkpoints, and logical lanes above it.

### Future Phase: DNS / URL Bridge

Explore aliases such as:

```text
example.com -> darwin://global.registry.us.hostingcluster7.webnode3.example_service
```

This would remain a future compatibility experiment, not a v0.1 simulator requirement.

## Design Rules

Keep these rules close while building:

```text
Identity is stable. Attachment is temporary.
Device labels are scoped. Device IDs are durable.
Registry paths and traffic paths may diverge.
Registry Hubs manage identity and authority.
Traffic Hubs manage movement and lane behavior.
Passports are for cross-network identity.
Local rolling proof is for same-network continuity.
Move Contracts record verified relocation.
Checkpoints report liveness and state.
Logical Lanes belong to authenticated device identities.
Pause senders during relocation instead of growing unbounded buffers.
Model behavior first. Add real cryptography and real networking later.
```

## License

TBD.

## Project Note

DARWIN is a thought experiment and prototype architecture. It should be developed with careful skepticism, observable simulations, and small testable milestones. The goal is not to claim a finished system. The goal is to build a clean playground where the model can prove, break, and refine itself.
