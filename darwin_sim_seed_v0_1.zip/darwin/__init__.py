"""DARWIN simulator package.

DARWIN stands for Direct-Access Registration Window Interface Network.
This package is intentionally simulator-first: behavior now, real networking
and production cryptography later.
"""

__all__ = ["__version__"]

__version__ = "0.1.0"
