"""Minimal command-line entry point for DARWIN simulator."""

from __future__ import annotations

import argparse

import darwin
from darwin.sim.runner import run_scenario


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="darwin-sim")
    parser.add_argument("--version", action="store_true", help="print version and exit")
    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="run a scenario file")
    run_parser.add_argument("scenario", help="path to a YAML or JSON scenario file")

    subparsers.add_parser("list-scenarios", help="placeholder for scenario discovery")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.version:
        print(f"darwin-sim {darwin.__version__}")
        return 0

    if args.command == "run":
        print(run_scenario(args.scenario))
        return 0

    if args.command == "list-scenarios":
        print("scenario discovery placeholder")
        return 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
