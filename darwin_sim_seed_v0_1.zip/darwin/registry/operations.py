"""Registry operation placeholders."""

from __future__ import annotations

from darwin.models.hub import RegistryHub


def assign_temp_label(requested_label: str, device_id: str) -> str:
    """Return the default conflict label for a duplicate local label."""
    return f"{requested_label}_temp_{device_id[-4:]}"


def resolve_label(hub: RegistryHub, label: str) -> str | None:
    """Resolve a local label to a device ID if known."""
    return hub.labels.get(label)
