"""Checkpoint state placeholders."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class CheckpointState:
    device_id: str
    state: str
    checkpoint_tier: int
    last_checkpoint_at: int
    missed_checkpoint_count: int = 0
    auth_valid: bool = True
