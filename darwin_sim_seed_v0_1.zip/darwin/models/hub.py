"""Hub model placeholders for DARWIN."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class RegistryHub:
    """A scoped identity registry for simulated devices."""

    hub_id: str
    scope_path: str
    parent_hub_id: str | None = None
    labels: dict[str, str] = field(default_factory=dict)
    devices: dict[str, str] = field(default_factory=dict)

    def identity_chain_for(self, label: str) -> str:
        """Return the full identity chain for a label in this scope."""
        return f"{self.scope_path}.{label}"


@dataclass(slots=True)
class TrafficHub:
    """A packet and lane movement hub for simulated routes."""

    hub_id: str
    neighbors: set[str] = field(default_factory=set)
    direct_attachments: set[str] = field(default_factory=set)

    def connect_neighbor(self, other_hub_id: str) -> None:
        self.neighbors.add(other_hub_id)

    def attach_device(self, device_id: str) -> None:
        self.direct_attachments.add(device_id)
