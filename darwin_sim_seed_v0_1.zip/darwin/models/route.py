"""Route record placeholders."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class RouteRecord:
    target_id: str
    route: list[str] = field(default_factory=list)
    route_status: str = "advisory"
    cost: float = 0.0

    @property
    def next_hop(self) -> str | None:
        return self.route[0] if self.route else None
