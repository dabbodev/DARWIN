"""Logical lane model placeholders."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class LogicalLane:
    lane_id: str
    source_device_id: str
    target_device_id: str
    lane_mode: str = "reliable_ordered"
    state: str = "opening"
    current_route: list[str] = field(default_factory=list)
    last_sent_sequence: int = 0
    last_acknowledged_sequence: int = 0
    flow_state: str = "normal"
    relocation_state: str = "none"

    def activate(self) -> None:
        self.state = "active"

    def pause_for_relocation(self) -> None:
        self.state = "paused_relocation"
        self.flow_state = "flow_hold"
        self.relocation_state = "in_transit"

    def resume(self) -> None:
        self.state = "active"
        self.flow_state = "normal"
        self.relocation_state = "resumed"
