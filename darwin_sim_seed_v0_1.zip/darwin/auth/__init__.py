"""DARWIN simulator subpackage."""
