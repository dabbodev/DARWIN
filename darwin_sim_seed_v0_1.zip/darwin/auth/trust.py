"""Trust escalation helpers will live here."""
