"""Symbolic authentication checks for simulator v0.1.

These helpers deliberately do not implement production cryptography.
They let scenarios model trust success and trust failure before real
signatures, MACs, or key exchange are introduced.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SymbolicAuthState:
    passport_valid: bool = True
    issuer_trusted: bool = True
    move_contract_valid: bool = True
    rolling_proof_valid: bool = True
    packet_auth_tag_valid: bool = True

    @property
    def all_valid(self) -> bool:
        return all((
            self.passport_valid,
            self.issuer_trusted,
            self.move_contract_valid,
            self.rolling_proof_valid,
            self.packet_auth_tag_valid,
        ))
