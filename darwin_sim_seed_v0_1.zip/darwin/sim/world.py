"""World container for DARWIN simulator state."""

from __future__ import annotations

from dataclasses import dataclass, field

from darwin.models.device import Device
from darwin.models.hub import RegistryHub, TrafficHub
from darwin.models.lane import LogicalLane


@dataclass(slots=True)
class World:
    current_time: int = 0
    devices: dict[str, Device] = field(default_factory=dict)
    registry_hubs: dict[str, RegistryHub] = field(default_factory=dict)
    traffic_hubs: dict[str, TrafficHub] = field(default_factory=dict)
    lanes: dict[str, LogicalLane] = field(default_factory=dict)
    events: list[str] = field(default_factory=list)

    def add_device(self, device: Device) -> None:
        self.devices[device.device_id] = device

    def add_registry_hub(self, hub: RegistryHub) -> None:
        self.registry_hubs[hub.hub_id] = hub

    def add_traffic_hub(self, hub: TrafficHub) -> None:
        self.traffic_hubs[hub.hub_id] = hub

    def advance_time(self, ticks: int = 1) -> None:
        if ticks < 0:
            raise ValueError("ticks must be non-negative")
        self.current_time += ticks

    def snapshot(self) -> dict[str, object]:
        return {
            "time": self.current_time,
            "devices": sorted(self.devices),
            "registry_hubs": sorted(self.registry_hubs),
            "traffic_hubs": sorted(self.traffic_hubs),
            "lanes": sorted(self.lanes),
        }
