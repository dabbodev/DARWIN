"""Scenario assertion helpers will live here."""
