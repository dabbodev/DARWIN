    """Simple human-readable simulator event log."""

    from __future__ import annotations

    from dataclasses import dataclass, field


    @dataclass(slots=True)
    class EventLog:
        lines: list[str] = field(default_factory=list)

        def write(self, time: int, message: str) -> None:
            self.lines.append(f"[t={time}] {message}")

        def render(self) -> str:
            return "
".join(self.lines)
