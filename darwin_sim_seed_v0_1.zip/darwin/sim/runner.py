"""Scenario runner placeholder."""

from __future__ import annotations

from pathlib import Path


def run_scenario(path: str | Path) -> str:
    """Placeholder runner used until scenario parsing is implemented."""
    scenario_path = Path(path)
    if not scenario_path.exists():
        raise FileNotFoundError(scenario_path)
    return f"scenario placeholder loaded: {scenario_path}"
