"""Routing helpers for v0.1 simulator experiments."""

from __future__ import annotations


def route_cost(latency_ms: float, congestion_penalty: float = 0.0, trust_penalty: float = 0.0) -> float:
    """Compute the intentionally simple v0.1 route cost."""
    return latency_ms + congestion_penalty + trust_penalty
