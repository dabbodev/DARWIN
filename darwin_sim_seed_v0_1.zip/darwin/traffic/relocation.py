"""Relocation pause/resume helpers will live here."""
